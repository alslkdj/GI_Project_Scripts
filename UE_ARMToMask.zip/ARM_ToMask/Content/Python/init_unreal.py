import unreal



def OnAssetPostImport (factory:unreal.Factory, object:unreal.Object):   
    if object.get_path_name().endswith("_ARM"):
        eas = unreal.get_editor_subsystem(unreal.EditorAssetSubsystem)
        tag_name = "reimported"
        if eas:
            if eas.get_metadata_tag(object, tag_name):       
                print(object.get_name(),"is already imported!")    
            else: 
                eas.set_metadata_tag(object, tag_name, "True")
                print(object.get_name(), "tag setting done.")

                if isinstance(object, unreal.Texture2D):
                    object.set_editor_property("compression_settings", unreal.TextureCompressionSettings.TC_MASKS)
                    print(object.get_name(), "compression setting changed.")
    else: print (object.get_name(), "is not ends with _ARM.")



import_subsystem = unreal.get_editor_subsystem(unreal.ImportSubsystem)
if import_subsystem :
    import_subsystem.on_asset_post_import.add_callable(OnAssetPostImport)

